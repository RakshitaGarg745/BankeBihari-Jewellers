import axios from "axios";

const API = "http://localhost:3001/booking";

export const createBooking = async (bookingData) => {
    const token = localStorage.getItem("token");

    const response = await axios.post(
        `${API}/create`,
        bookingData,
        {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }
    );

    return response.data;
};

export const getMyBookings = async () => {
    const token = localStorage.getItem("token");

    const response = await axios.get(
        `${API}/my-bookings`,
        {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }
    );

    return response.data;
};

export const cancelBooking = async (bookingId) => {

    const token = localStorage.getItem("token");

    const response = await axios.put(
        `http://localhost:3001/booking/cancel/${bookingId}`,
        {},
        {
            headers: {
                Authorization: `Bearer ${token}`
            }
        }
    );

    return response.data;

};

export const payAdvance = async (paymentData) => {

    const token = localStorage.getItem("token");

    const response = await axios.post(

        `${API}/pay-advance`,

        paymentData,

        {

            headers: {

                Authorization: `Bearer ${token}`

            }

        }

    );

    return response.data;

};


   