import axios from "axios";

const API = "http://localhost:3001/payment";

export const createOrder = async (amount) => {
  const res = await axios.post(`${API}/create-order`, {
    amount,
  });

  return res.data;
};

export const verifyPayment = async (paymentData) => {
  const res = await axios.post(`${API}/verify`, paymentData);

  return res.data;
};