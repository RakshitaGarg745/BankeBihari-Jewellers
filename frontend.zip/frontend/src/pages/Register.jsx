import { useState } from "react";
import { registerCustomer } from "../services/authService";
import { useNavigate } from "react-router-dom";

function Register() {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        full_name: "",
        email: "",
        phone: "",
        address: "",
        password: ""
    });

    const handleChange = (e) => {

        setFormData({

            ...formData,
            [e.target.name]: e.target.value

        });

    };

    const handleSubmit = async (e) => {

        e.preventDefault();

        try {

            await registerCustomer(formData);

            alert("Registration Successful");

            navigate("/login");

        }

        catch (err) {

            alert(err.response?.data?.message || "Registration Failed");

        }

    };

    return (

        <div className="container mt-5">

            <h2>Customer Registration</h2>

            <form onSubmit={handleSubmit}>

                <input
                    className="form-control mb-3"
                    name="full_name"
    placeholder="Name"
    onChange={handleChange}
                    required
                />

                <input
                    className="form-control mb-3"
                    name="email"
                    placeholder="Email"
                    onChange={handleChange}
                    required
                />

                <input
                    className="form-control mb-3"
                    name="phone"
                    placeholder="Phone"
                    onChange={handleChange}
                    required
                />

                <input
                    className="form-control mb-3"
                    name="address"
                    placeholder="Address"
                    onChange={handleChange}
                    required
                />

                <input
                    type="password"
                    className="form-control mb-3"
                    name="password"
                    placeholder="Password"
                    onChange={handleChange}
                    required
                />

                <button className="btn btn-success">
                    Register
                </button>

            </form>

        </div>

    );

}

export default Register;