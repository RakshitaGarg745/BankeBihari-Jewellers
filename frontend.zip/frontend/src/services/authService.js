import axios from "axios";

// Backend API Base URL
const API = "http://localhost:3001/customers";

// -------------------------
// Customer Registration
// -------------------------
export const registerCustomer = async (customerData) => {
    return await axios.post(`${API}/register`, customerData);
};

// -------------------------
// Customer Login
// -------------------------
export const loginCustomer = async (loginData) => {
    return await axios.post(`${API}/login`, loginData);
};

// -------------------------
// Get Logged-in Customer Profile
// -------------------------
export const getProfile = async (token) => {
    return await axios.get(`${API}/profile`, {
        headers: {
            Authorization: `Bearer ${token}`,
        },
    });
};