import { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { createBooking } from "../services/bookingService";

function BookingPage() {

    const navigate = useNavigate();
    const location = useLocation();

    const product = location.state?.product;

    const [advanceAmount, setAdvanceAmount] = useState("");
    const [deliveryType, setDeliveryType] = useState("Visit Shop");

    if (!product) {
        return (
            <div className="container mt-5">
                <h3>No Product Selected</h3>
            </div>
        );
    }

    const handleSubmit = async (e) => {

        e.preventDefault();

        const today = new Date();

        const expiry = new Date();
        expiry.setDate(today.getDate() + 7);

        const bookingDate = today.toISOString().split("T")[0];
        const bookingExpiry = expiry.toISOString().split("T")[0];
        if (Number(advanceAmount) > product.price) {
            alert("Advance amount cannot be greater than product price.");
            return;
        }
        try {

            await createBooking({

                product_id: product.product_id,

                booking_date: bookingDate,

                booking_expiry: bookingExpiry,

                advance_amount: Number(advanceAmount),

                remaining_amount:
                    product.price - Number(advanceAmount),

                delivery_type: deliveryType

            });

            alert("Booking Created Successfully!");

            navigate("/my-bookings");

        } catch (err) {

            console.log(err);

            if (err.response) {
                alert(err.response.data.message);
            } else {
                alert("Booking Failed");
            }

        }

    };

    return (

        <div className="container mt-5">

            <div className="card shadow p-4">

                <h2 className="mb-4">
                    Book Jewellery
                </h2>

                <hr />

                <h4>{product.product_name}</h4>

                <p>
                    <strong>Category :</strong> {product.category}
                </p>

                <p>
                    <strong>Metal :</strong> {product.metal}
                </p>

                <p>
                    <strong>Weight :</strong> {product.weight} g
                </p>

                <p>
                    <strong>Price :</strong> ₹ {product.price}
                </p>

                <form onSubmit={handleSubmit}>

                    <div className="mb-3">

                        <label className="form-label">
                            Advance Amount
                        </label>

                        <input
    type="number"
    className="form-control"
    placeholder="Enter Advance Amount"
    value={advanceAmount}
    min="0"
    max={product.price}
    onChange={(e) => setAdvanceAmount(e.target.value)}
    required
/>

                    </div>

                    <div className="mb-3">

                        <label className="form-label">
                            Delivery Type
                        </label>

                        <select
                            className="form-control"
                            value={deliveryType}
                            onChange={(e) =>
                                setDeliveryType(e.target.value)
                            }
                        >

                            <option value="Visit Shop">
                                Visit Shop
                            </option>

                            <option value="Home Delivery">
                                Home Delivery
                            </option>

                        </select>

                    </div>

                    <div className="alert alert-info">

                        <strong>Booking Policy</strong>

                        <br />

                        • Booking will remain valid for <b>7 days</b>.

                        <br />

                        • Remaining amount must be paid before the booking expires.

                    </div>

                    <button
                        type="submit"
                        className="btn btn-warning w-100"
                    >
                        Confirm Booking
                    </button>

                </form>

            </div>

        </div>

    );

}

export default BookingPage;