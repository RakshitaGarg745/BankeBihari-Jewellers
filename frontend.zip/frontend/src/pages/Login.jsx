import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { loginCustomer } from "../services/authService";

function Login() {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        email: "",
        password: ""
    });

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e) => {

        if (e) e.preventDefault();
    
        console.log("Customer Login Clicked");
    
        try {
    
            const res = await loginCustomer(formData);
    
            console.log("LOGIN RESPONSE:", res.data);
    
            localStorage.setItem("token", res.data.token);
            localStorage.setItem("customer", JSON.stringify(res.data.customer));
    
            alert("Login Successful");
    
            navigate("/profile");
    
        } catch (err) {
    
            console.log("LOGIN ERROR:", err);
    
            alert(err.response?.data?.message || "Login Failed");
        }
    };

    return (

        <div className="container mt-5">

            <div className="row justify-content-center">

                <div className="col-md-5">

                    <div className="card shadow p-4">

                    <h2
    className="text-center mb-4"
    style={{ color: "red", fontSize: "50px" }}
>
    TEST CUSTOMER LOGIN
</h2>

                        <form onSubmit={handleSubmit}>

                            <div className="mb-3">

                                <label>Email</label>

                                <input
                                    type="email"
                                    name="email"
                                    className="form-control"
                                    value={formData.email}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <div className="mb-3">

                                <label>Password</label>

                                <input
                                    type="password"
                                    name="password"
                                    className="form-control"
                                    value={formData.password}
                                    onChange={handleChange}
                                    required
                                />

                            </div>

                            <button
    type="button"
    className="btn btn-primary w-100"
    onClick={handleSubmit}
>
    Login
</button>

                        </form>

                        <div className="text-center mt-4">

    <hr />

    <p>Are you the shop owner?</p>

    <button
        className="btn btn-dark"
        onClick={() => navigate("/admin/login")}
    >
        Owner Login
    </button>

</div>

                        <div className="text-center mt-3">

                            Don't have an account?

                            <br />

                            <Link to="/register">

                                Register Here

                            </Link>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    );

}


export default Login;